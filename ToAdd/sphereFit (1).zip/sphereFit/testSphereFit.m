dataStruct = load('data.mat');
data  = dataStruct.data;
[r,a,b,c] = sphereFit(data);
disp(sprintf('Radius = %2.3f\nCenter = [%2.3f, %2.3f, %2.3f]',r,a,b,c));